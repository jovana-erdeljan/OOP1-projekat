package servisi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import modeli.Dogadjaj;
import modeli.Mesto;
import pomocno.CSVBaza;

public class DogadjajServis {
    private static final String DOGADJAJI_FILE = "baza/dogadjaji.csv";
    private static final String KARTE_FILE = "baza/karte.csv";
	private static Scanner sc = new Scanner(System.in);

	public void kreiranjeDogadjaja() {
	    System.out.print("Unesite ID događaja: ");
	    String id = sc.nextLine();
	    System.out.print("Unesite naziv događaja: ");
	    String naziv = sc.nextLine();
	    System.out.print("Unesite datum početka (YYYY-MM-DD): ");
	    String pocetak = sc.nextLine();
	    System.out.print("Unesite datum kraja (YYYY-MM-DD): ");
	    String kraj = sc.nextLine();
	    System.out.print("Unesite sadržaj događaja (opis): ");
	    String sadrzaj = sc.nextLine();
	    // unos mesta
	    System.out.print("Unesite naziv mesta: ");
	    String nazivMesta = sc.nextLine();
	    System.out.print("Unesite adresu mesta: ");
	    String adresa = sc.nextLine();
	    System.out.print("Unesite prostoriju (opciono, pritisnite Enter ako nema): ");
	    String prostorija = sc.nextLine();

	    Mesto mesto = new Mesto(nazivMesta, adresa, prostorija);

	    // kreiraj objekat Dogadjaj
	    Dogadjaj dogadjaj = new Dogadjaj(
	            id,
	            naziv,
	            java.time.LocalDate.parse(pocetak),
	            java.time.LocalDate.parse(kraj),
	            sadrzaj,
	            mesto
	    );

	    // serijalizacija u CSV (mesto se zapisuje kao "naziv|adresa|prostorija")
	    String dogadjajCSV = CSVBaza.toCSVLine(Arrays.asList(
	            dogadjaj.getIdentifikator(),
	            naziv,
	            pocetak,
	            kraj,
	            sadrzaj,
	            mesto.getNaziv() + "|" + mesto.getAdresa() + "|" + mesto.getProstorija()
	    ));

	    List<String> dogadjaji = CSVBaza.readLines(DOGADJAJI_FILE);
	    dogadjaji.add(dogadjajCSV);
	    CSVBaza.writeLines(DOGADJAJI_FILE, dogadjaji);

	    System.out.println("Događaj uspešno kreiran!");

	    // kreiranje karata za događaj
	    dodajKarteZaDogadjaj(dogadjaj);
	}
	
	private void dodajKarteZaDogadjaj(Dogadjaj dogadjaj) {
	    System.out.println("Unesite broj individualnih karata: ");
	    int brojInd = Integer.parseInt(sc.nextLine());
	    System.out.println("Unesite cenu individualne karte: ");
	    double cenaInd = Double.parseDouble(sc.nextLine());

	    System.out.println("Unesite broj grupnih karata: ");
	    int brojGrup = Integer.parseInt(sc.nextLine());
	    System.out.println("Unesite cenu grupne karte: ");
	    double cenaGrup = Double.parseDouble(sc.nextLine());

	    System.out.println("Unesite broj porodičnih karata: ");
	    int brojPorod = Integer.parseInt(sc.nextLine());
	    System.out.println("Unesite cenu porodične karte: ");
	    double cenaPorod = Double.parseDouble(sc.nextLine());

	    List<String> noveKarte = new ArrayList<>();

	    // generisanje ID-a karata
	    int counter = 1;

	    for (int i = 0; i < brojInd; i++) {
	        String id = dogadjaj.getIdentifikator() + "-" + counter++;
	        noveKarte.add(CSVBaza.toCSVLine(Arrays.asList(
	                id, dogadjaj.getIdentifikator(), "INDIVIDUALNA", String.valueOf(cenaInd), "", "false"
	        )));
	    }

	    for (int i = 0; i < brojGrup; i++) {
	        String id = dogadjaj.getIdentifikator() + "-" + counter++;
	        noveKarte.add(CSVBaza.toCSVLine(Arrays.asList(
	                id, dogadjaj.getIdentifikator(), "GRUPNA", String.valueOf(cenaGrup), "", "false"
	        )));
	    }

	    for (int i = 0; i < brojPorod; i++) {
	        String id = dogadjaj.getIdentifikator() + "-" + counter++;
	        noveKarte.add(CSVBaza.toCSVLine(Arrays.asList(
	                id, dogadjaj.getIdentifikator(), "PORODICNA", String.valueOf(cenaPorod), "", "false"
	        )));
	    }

	    // upis u fajl
	    List<String> sveKarte = CSVBaza.readLines(KARTE_FILE);
	    sveKarte.addAll(noveKarte);
	    CSVBaza.writeLines(KARTE_FILE, sveKarte);
	    System.out.println("Karte uspešno dodate!");
	}
	
    public void pretragaDogadjaja() {
        System.out.println("Pretraga događaja po nazivu:");
        String naziv = sc.nextLine();
        List<String> lines = CSVBaza.readLines(DOGADJAJI_FILE);
        for (String line : lines) {
            List<String> f = CSVBaza.parseCSVLine(line);
            if (f.get(1).toLowerCase().contains(naziv.toLowerCase())) {
                System.out.println("Pronađen događaj: " + line);
            }
        }
    }
}
