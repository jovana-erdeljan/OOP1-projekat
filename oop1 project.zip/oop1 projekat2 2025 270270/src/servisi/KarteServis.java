package servisi;

import java.util.List;
import java.util.Scanner;

import korisnici.Clan;
import korisnici.Korisnik;
import korisnici.Organizator;
import modeli.VrstaKarte;
import pomocno.CSVBaza;

public class KarteServis {
	private DogadjajServis dogadjajServis = new DogadjajServis();
    private final String KARTE_FILE = "baza/karte.csv";
	private Scanner sc = new Scanner(System.in);
	
	public void kupovinaKarte(Korisnik prijavljenKorisnik) {
		dogadjajServis.pretragaDogadjaja();

	    System.out.print("Unesite ID događaja za koji želite da kupite kartu: ");
	    String dogId = sc.nextLine();
	    
        System.out.print("Unesite tip karte (1. individualna, 2. grupna, 3. porodicna):");
        int izbor = Integer.parseInt(sc.nextLine()); // korisnik unosi 1, 2 ili 3
        VrstaKarte izborKarte = VrstaKarte.values()[izbor - 1]; // -1 jer ordinal počinje od 0

	    List<String> lines = CSVBaza.readLines(KARTE_FILE);
	    boolean pronadjena = false;

	    for (String line : lines) {
	        List<String> f = CSVBaza.parseCSVLine(line);
	        String kartaId = f.get(0);
	        String dogadjajId = f.get(1);
	        String vrsta = f.get(2);
	        String cena = f.get(3);
	        String kupac = f.get(4);

	        if (dogadjajId.equals(dogId) && kupac.isEmpty() && vrsta.equals(izborKarte.name())) {
	            System.out.println("Dostupna karta: " + kartaId + " | Vrsta: " + vrsta + " | Cena: " + cena);
	            System.out.print("Kupiti ovu kartu? (da/ne): ");
	            if (sc.nextLine().equalsIgnoreCase("da")) {
	                f.set(4, prijavljenKorisnik.getKorisnickoIme()); // postavi kupca
	                String nova = CSVBaza.toCSVLine(f);
	                lines.set(lines.indexOf(line), nova);
	                CSVBaza.writeLines(KARTE_FILE, lines);
	                System.out.println("Karta kupljena!");
	                pronadjena = true;
	                break;
	            }
	        }
	    }

	    if (!pronadjena) {
	        System.out.println("Nema dostupnih karata za ovaj događaj.");
	    }
	}
	
	public void validacijaKarte() {
	    System.out.print("Unesite ID karte za validaciju: ");
	    String id = sc.nextLine();

	    List<String> lines = CSVBaza.readLines(KARTE_FILE);
	    for (String line : lines) {
	        List<String> f = CSVBaza.parseCSVLine(line);
	        String kartaId = f.get(0);
	        String kupac = f.get(4);
	        String iskoriscena = f.get(5);

	        if (kartaId.equals(id)) {
	            if (!kupac.isEmpty() && iskoriscena.equals("false")) {
	                System.out.println("Karta je validna (ima kupca i nije iskorišćena).");
	            } else {
	                System.out.println("Karta nije validna.");
	            }
	            return;
	        }
	    }
	    System.out.println("Karta sa datim ID-jem nije pronađena.");
	}
	
    public void prikazKupljenihKarata(Korisnik prijavljenKorisnik) {
        List<String> lines = CSVBaza.readLines(KARTE_FILE);

        if (prijavljenKorisnik instanceof Clan) {
            System.out.println("=== Kupljene karte za člana " + prijavljenKorisnik.getKorisnickoIme() + " ===");
            for (String line : lines) {
                List<String> f = CSVBaza.parseCSVLine(line);
                String kupac = f.get(4);
                String iskoriscena = f.get(5);

                if (kupac.equals(prijavljenKorisnik.getKorisnickoIme()) && iskoriscena.equals("false")) {
                    System.out.println("Karta: " + line);
                }
            }
        } else if (prijavljenKorisnik instanceof Organizator) {
            System.out.print("Unesite ID događaja: ");
            String dogId = sc.nextLine();
            System.out.println("=== Kupljene karte za događaj " + dogId + " ===");
            for (String line : lines) {
                List<String> f = CSVBaza.parseCSVLine(line);
                String dogadjajId = f.get(1);
                String kupac = f.get(4);

                if (dogadjajId.equals(dogId) && !kupac.isEmpty()) {
                    System.out.println("Karta: " + line);
                }
            }
        } else {
            System.out.println("Ova funkcionalnost nije dostupna za vaš tip korisnika.");
        }
    }
    
    public void aktivacijaKarte() {
        System.out.print("Unesite ID karte za aktivaciju: ");
        String id = sc.nextLine();

        List<String> lines = CSVBaza.readLines(KARTE_FILE);
        for (int i = 0; i < lines.size(); i++) {
            List<String> f = CSVBaza.parseCSVLine(lines.get(i));
            String kartaId = f.get(0);
            String kupac = f.get(4);
            String iskoriscena = f.get(5);

            if (kartaId.equals(id)) {
                if (!kupac.isEmpty() && iskoriscena.equals("false")) {
                    f.set(5, "true"); // aktiviraj kartu
                    lines.set(i, CSVBaza.toCSVLine(f));
                    CSVBaza.writeLines(KARTE_FILE, lines);
                    System.out.println("Karta " + id + " je aktivirana!");
                } else {
                    System.out.println("Karta nije validna za aktivaciju.");
                }
                return;
            }
        }
        System.out.println("Karta sa datim ID-jem nije pronađena.");
    }
    
    public void prikazAktiviranihKarata() {
        System.out.print("Unesite ID događaja: ");
        String dogId = sc.nextLine();

        List<String> lines = CSVBaza.readLines(KARTE_FILE);
        boolean pronadjena = false;

        System.out.println("=== Aktivirane karte za događaj " + dogId + " ===");
        for (String line : lines) {
            List<String> f = CSVBaza.parseCSVLine(line);
            String dogadjajId = f.get(1);
            String iskoriscena = f.get(5);

            if (dogadjajId.equals(dogId) && iskoriscena.equals("true")) {
                System.out.println("Karta: " + line);
                pronadjena = true;
            }
        }

        if (!pronadjena) {
            System.out.println("Nema aktiviranih karata za ovaj događaj.");
        }
    }
}
