package servisi;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import korisnici.Clan;
import korisnici.Korisnik;
import korisnici.Organizator;
import korisnici.Validator;
import pomocno.CSVBaza;

public class KorisnikServis {
	private final String KORISNICI_FILE = "baza/korisnici.csv";
	private Korisnik prijavljenKorisnik;
	private Scanner sc = new Scanner(System.in);
	
	public void registracijaKorisnika()
	{
        System.out.print("Unesite korisničko ime: ");
        String korisnickoIme = sc.nextLine();
        System.out.print("Unesite lozinku: ");
        String lozinka = sc.nextLine();
        System.out.print("Unesite telefon: ");
        String telefon = sc.nextLine();

        String novi = CSVBaza.toCSVLine(Arrays.asList("Clan", korisnickoIme, lozinka, telefon, "0"));
        CSVBaza.appendLine(KORISNICI_FILE, novi);
        System.out.println("Uspešno registrovan član!");
	}
	
	public void prijavaKorisnika()
	{
		System.out.println("Unesite vase korisnicko ime:");
		String korisnickoIme = sc.nextLine();
		System.out.println("Unesite vasu lozinku:");
		String lozinka = sc.nextLine();
		
        List<String> lines = CSVBaza.readLines(KORISNICI_FILE);
        for (String line : lines) {
            List<String> fields = CSVBaza.parseCSVLine(line);
            String tip = fields.get(0);
            String postojeceKorisnickoIme = fields.get(1);
            String postojecaLozinka = fields.get(2);

            if (postojeceKorisnickoIme.equals(korisnickoIme) && postojecaLozinka.equals(lozinka)) {
                switch (tip) {
                    case "Clan":
                    	setPrijavljenKorisnik(new Clan(postojeceKorisnickoIme, postojecaLozinka, fields.get(3)));
                        break;
                    case "Organizator":
                    	setPrijavljenKorisnik(new Organizator(postojeceKorisnickoIme, postojecaLozinka));
                        break;
                    case "Validator":
                    	setPrijavljenKorisnik(new Validator(postojeceKorisnickoIme, postojecaLozinka));
                        break;
                }
                System.out.println("Uspešno prijavljeni kao " + getPrijavljenKorisnik().getKorisnickoIme());
                return;
            }
        }
        System.out.println("Neuspešna prijava.");
	}
	
	public void odjavaKorisnika()
	{
		setPrijavljenKorisnik(null);
	}

	public Korisnik getPrijavljenKorisnik() {
		return prijavljenKorisnik;
	}

	private void setPrijavljenKorisnik(Korisnik prijavljenKorisnik) {
		this.prijavljenKorisnik = prijavljenKorisnik;
	}
}
