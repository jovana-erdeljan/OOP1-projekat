package modeli;
import java.time.LocalDate;
import interfejsi.Validirajuce;
import korisnici.Clan;

public class Karta implements Validirajuce {
	private String identifikator;
	private Clan kupac;
	private double cena;
	private VrstaKarte vrtaKarte;
	private Dogadjaj dogadjaj;
	private boolean iskoriscena;
	
    public Karta(String identifikator, double cena, VrstaKarte vrtaKarte, Dogadjaj dogadjaj) {
        this.identifikator = identifikator;
        this.cena = cena;
        this.vrtaKarte = vrtaKarte;
        this.dogadjaj = dogadjaj;
        this.iskoriscena = false;
    }	
	
	@Override
	public boolean validiraj() {
		return (kupac != null && 
				!iskoriscena &&
				LocalDate.now().isAfter(dogadjaj.getDatumPocetka()) &&
				LocalDate.now().isBefore(dogadjaj.getDatumKraja()));
	}

	@Override
	public boolean aktiviraj() {
		if (validiraj())
		{
			iskoriscena = true;
			return true;
		}
		return false;
	}
}
