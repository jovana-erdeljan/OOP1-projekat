package modeli;

public class Mesto {
	private String naziv;
	private String adresa;
	private String prostorija;
	
    public Mesto(String naziv, String adresa, String prostorija) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.prostorija = prostorija;
    }

    public String getNaziv() { return naziv; }
    public String getAdresa() { return adresa; }
    public String getProstorija() { return prostorija; }

    @Override
    public String toString() {
        return naziv + " (" + adresa + (prostorija.isEmpty() ? "" : ", " + prostorija) + ")";
    }
}
