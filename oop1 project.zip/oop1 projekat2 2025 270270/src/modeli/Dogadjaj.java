package modeli;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Dogadjaj {
	private String identifikator;
	private String naziv;
	private LocalDate datumPocetka;
	private LocalDate datumKraja;
	private String sadrzaj;
	private Mesto mestoOdrzavanja;
	
    public Dogadjaj(String identifikator, String naziv, LocalDate datumPocetka, LocalDate datumKraja, String sadrzaj, Mesto mestoOdrzavanja) {
        this.identifikator = identifikator;
        this.naziv = naziv;
        this.datumPocetka = datumPocetka;
        this.datumKraja = datumKraja;
        this.sadrzaj = sadrzaj;
        this.mestoOdrzavanja = mestoOdrzavanja;
    }

	public String getIdentifikator() {
		return identifikator;
	}

	LocalDate getDatumKraja() {
		return datumKraja;
	}

	LocalDate getDatumPocetka() {
		return datumPocetka;
	}
}
