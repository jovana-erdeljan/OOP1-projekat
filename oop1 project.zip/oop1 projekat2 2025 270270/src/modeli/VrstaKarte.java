package modeli;

public enum VrstaKarte {
	INDIVIDUALNA, 
	GRUPNA, 
	PORODICNA
}
