package interfejsi;

public interface Validirajuce {
	boolean validiraj();
	boolean aktiviraj();
}
