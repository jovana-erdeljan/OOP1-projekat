
import java.util.Scanner;
import korisnici.Clan;
import korisnici.Korisnik;
import korisnici.Organizator;
import korisnici.Validator;
import servisi.DogadjajServis;
import servisi.KarteServis;
import servisi.KorisnikServis;

public class Platforma {
    private static String naziv;
    private static Korisnik prijavljenKorisnik;
	private static Scanner sc = new Scanner(System.in);
	private static DogadjajServis dogadjajServis = new DogadjajServis();
	private static KarteServis karteServis = new KarteServis();
	private static KorisnikServis korisnikServis = new KorisnikServis();
	
	public static void main(String[] args) {
		while (true) {
	        if (prijavljenKorisnik == null) {
	        	System.out.println();
	            System.out.println("1. Prijava");
	            System.out.println("2. Registracija");
	            System.out.println("3. Izlaz");
	            System.out.print("Izbor: ");
	            String izbor = sc.nextLine();
	
	            switch (izbor) {
	                case "1":
	                	korisnikServis.prijavaKorisnika();
	                	prijavljenKorisnik = korisnikServis.getPrijavljenKorisnik();
	                	break;
	                case "2": korisnikServis.registracijaKorisnika(); break;
	                case "3": System.out.println("Izlaz"); return;
	                default: System.out.println("Pogrešan izbor.");
	            }
	        } else {
	            meniZaKorisnika();
	        }
		}
	}
	
    private static void meniZaKorisnika() {
        System.out.println("\n--- Meni za " + prijavljenKorisnik.getKorisnickoIme() + " ---");
        System.out.println("1. Odjava");

        if (prijavljenKorisnik instanceof Clan) {
            System.out.println("2. Pretraga događaja");
            System.out.println("3. Kupovina karte");
            System.out.println("4. Prikaz kupljenih karata");
        } else if (prijavljenKorisnik instanceof Organizator) {
            System.out.println("2. Kreiranje događaja");
            System.out.println("3. Prikaz kupljenih karata za događaj");
            System.out.println("4. Prikaz aktiviranih karata");
        } else if (prijavljenKorisnik instanceof Validator) {
            System.out.println("2. Validacija karte");
            System.out.println("3. Aktivacija karte");
            System.out.println("4. Prikaz aktiviranih karata");
        }

        System.out.print("Izbor: ");
        String izbor = sc.nextLine();

        switch (izbor) {
            case "1":
            	korisnikServis.odjavaKorisnika();
            	prijavljenKorisnik = korisnikServis.getPrijavljenKorisnik();
            	break;
            case "2":
                if (prijavljenKorisnik instanceof Clan) dogadjajServis.pretragaDogadjaja();
                else if (prijavljenKorisnik instanceof Organizator) dogadjajServis.kreiranjeDogadjaja();
                else if (prijavljenKorisnik instanceof Validator) karteServis.validacijaKarte();
                break;
            case "3":
                if (prijavljenKorisnik instanceof Clan) karteServis.kupovinaKarte(prijavljenKorisnik);
                else if (prijavljenKorisnik instanceof Organizator) karteServis.prikazKupljenihKarata(prijavljenKorisnik);
                else if (prijavljenKorisnik instanceof Validator) karteServis.aktivacijaKarte();
                break;
            case "4":
                if (prijavljenKorisnik instanceof Clan) karteServis.prikazKupljenihKarata(prijavljenKorisnik);
                else karteServis.prikazAktiviranihKarata();
                break;
            default: System.out.println("Pogrešan izbor.");
        }
    }
}
