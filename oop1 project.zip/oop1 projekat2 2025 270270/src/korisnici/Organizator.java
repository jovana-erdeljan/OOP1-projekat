package korisnici;
import java.util.ArrayList;
import java.util.List;
import modeli.Dogadjaj;

public class Organizator extends Korisnik {
    private List<Dogadjaj> dogadjaji;

    public Organizator(String korisnickoIme, String lozinka) {
        super(korisnickoIme, lozinka);
        this.dogadjaji = new ArrayList<>();
    }

    @Override
    public String getTip() { return "Organizator"; }

    public void dodajDogadjaj(Dogadjaj d) {
        dogadjaji.add(d);
    }
}
