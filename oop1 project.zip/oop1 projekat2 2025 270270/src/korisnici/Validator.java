package korisnici;
public class Validator extends Korisnik {
    public Validator(String korisnickoIme, String lozinka) {
        super(korisnickoIme, lozinka);
    }

    @Override
    public String getTip() { return "Validator"; }	
}
