package korisnici;
import java.util.ArrayList;
import java.util.List;
import modeli.Karta;

public class Clan extends Korisnik {
	private String brojTelefona;
	private double novcanaSredstva;
	private List<Karta> kupljeneKarte;
	
	public Clan(String korisnickoIme, String lozinka, String brojTelefona) {
		super(korisnickoIme, lozinka);
        this.brojTelefona = brojTelefona;
        this.novcanaSredstva = 0;
        this.kupljeneKarte = new ArrayList<>();
	}

    @Override
    public String getTip() { return "Clan"; }

    public void dodajKartu(Karta k) {
        kupljeneKarte.add(k);
    }
}
