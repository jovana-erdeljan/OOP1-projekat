package pomocno;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CSVBaza {
    // Čitanje CSV fajla u listu stringova (svaki red kao string)
    public static List<String> readLines(String filePath) {
        List<String> lines = new ArrayList<>();
        try {
            lines = Files.readAllLines(Paths.get(filePath));
        } catch (IOException e) {
            System.err.println("Greška pri čitanju fajla: " + filePath);
        }
        return lines;
    }

    // Pisanje liste stringova u CSV fajl (overwrite)
    public static void writeLines(String filePath, List<String> lines) {
        try {
            Files.write(Paths.get(filePath), lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.err.println("Greška pri pisanju fajla: " + filePath);
        }
    }

    // Dodavanje jednog reda u CSV fajl (append)
    public static void appendLine(String filePath, String line) {
        try {
            Files.write(Paths.get(filePath), Arrays.asList(line), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Greška pri dodavanju reda u fajl: " + filePath);
        }
    }

    // Parsiranje CSV reda u listu polja
    public static List<String> parseCSVLine(String line) {
        // jednostavno split po zarezu
        return Arrays.asList(line.split(","));
    }

    // Pretvaranje liste polja u CSV red
    public static String toCSVLine(List<String> fields) {
        return String.join(",", fields);
    }
}
